// background.js

chrome.runtime.onInstalled.addListener(() => {
  console.log("CP Helper Extension installed");
});
